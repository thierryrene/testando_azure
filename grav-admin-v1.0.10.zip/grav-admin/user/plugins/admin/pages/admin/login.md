---
title: Admin Login

form:
    name: login
    action:
    method: post

    fields:
        - name: username
          type: text
          placeholder: Username
          autofocus: true

        - name: password
          type: password
          placeholder: Password
---


