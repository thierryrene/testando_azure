---
title: Forgot password

form:
    fields:
        - name: username
          type: text
          id: username
          placeholder: Username
          autofocus: true
---


# Recover your password

Enter your username to recover your password
